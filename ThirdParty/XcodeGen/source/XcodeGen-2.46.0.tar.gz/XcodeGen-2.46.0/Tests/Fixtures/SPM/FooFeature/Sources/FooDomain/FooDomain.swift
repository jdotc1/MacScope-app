public struct FooDomain {}
