public struct FooUI {}
