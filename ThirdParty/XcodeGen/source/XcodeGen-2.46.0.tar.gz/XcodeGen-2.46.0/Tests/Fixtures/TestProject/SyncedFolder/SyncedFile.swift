
struct SyncedStruct {
  
}
